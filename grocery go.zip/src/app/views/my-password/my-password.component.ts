import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-password',
  templateUrl: './my-password.component.html',
  styleUrls: ['./my-password.component.scss']
})
export class MyPasswordComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
